<html>
    <head>
        <link rel="stylesheet" href="css/style.css">
        <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    </head>
    <body>
        
        <form id='form' action='register' method='POST' autocomplete="off">
            <?php echo csrf_field(); ?>
            <input type='email' name='email' autocomplete="off" placeholder='email'><br>
            <input type='text' name='username' autocomplete="off" placeholder='username'><br>
            <input type="password" name="password"  autocomplete="new-password" placeholder='password'><br>
            <button type='submit' name='submit'>REGISTER</button>
            
            <a href='<?php echo e(route('welcome')); ?>'>BACK</a>
          </form>
    </body> 
</html><?php /**PATH C:\Users\Kian Yi Lim\Desktop\Y3S2\UECS3294 AWAD\ASSIGNMENT\Assignment\resources\views/auth/register.blade.php ENDPATH**/ ?>