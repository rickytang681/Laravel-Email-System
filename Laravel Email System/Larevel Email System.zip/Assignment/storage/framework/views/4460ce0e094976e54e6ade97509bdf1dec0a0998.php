<html>
    <head>
        <link rel="stylesheet" href="css/style.css">
        <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    </head>
    <body>
        <form id='form' action='login' method='post' autocomplete="off">
            <?php echo csrf_field(); ?>
            <?php if(Cookie::has('username')): ?>
                <input type="text" name="username" value="<?php echo e(Cookie::get('username')); ?>" autocomplete="off" placeholder="username">
            <?php else: ?>
                <input type='text' name='username' autocomplete="off" placeholder='username'><br>
            <?php endif; ?>

            <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <span class="invalid-feedback" role="alert">
                    <strong><?php echo e($message); ?></strong>
                </span>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            <?php if(Cookie::has('password')): ?>
                <input name="password" type="password" value="<?php echo e(Cookie::get('password')); ?>" autocomplete="new-password" placeholder='password'><br>
            <?php else: ?>
                <input name="password" type="password" autocomplete="new-password" placeholder='password'>
            <?php endif; ?>
            
            
            <input type="hidden" value='1'>
            <label style="color:white;">
                <input type="checkbox" value="remember-me" name="remember_me" <?php if(Cookie::has('username')): ?> checked <?php endif; ?>> Remember me
            </label>
            <button type='submit' name='submit'>LOGIN</button><br>
            <a href='<?php echo e(route('welcome')); ?>'>BACK</a>
        </form>
    </body>
    
</html>
<?php /**PATH C:\Users\Kian Yi Lim\Desktop\Y3S2\UECS3294 AWAD\ASSIGNMENT\Assignment\resources\views/auth/login.blade.php ENDPATH**/ ?>