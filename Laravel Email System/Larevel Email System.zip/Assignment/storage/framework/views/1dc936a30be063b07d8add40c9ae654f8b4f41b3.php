<head>
    <link rel="stylesheet" href="<?php echo e(asset('css/style.css')); ?>">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css"
        integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
</head>

<body>
    <div class="container">
        <div class="row justify-content-center">
            <div class="card">
                <div class="card-body">
                    Hello Admin, <?php echo e(session('email')); ?>

                </div>
            </div>


            <div class="col-md-10">
                <div class="card">
                    <div class="card-header bg-primary text-white">Primary Admin List</div>
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table table-bordered">
                                <thead>
                                    <tr>
                                        <th>ID</th>
                                        <th>Name</th>
                                        <th>Email</th>
                                        <th>Operation</th>
                                        <th>Operation</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $admins; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $admin): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($admin->id); ?></td>
                                            <td><?php echo e($admin->name); ?></td>
                                            <td><?php echo e($admin->email); ?></td>
                                            <td><a href=<?php echo e('deleteAdmin/' . $admin['id']); ?>

                                                    class="btn btn-danger btn-sm">Delete</a></td>
                                            <td><a href=<?php echo e('/edit-admin/' . $admin['id']); ?>

                                                    class="btn btn-danger btn-sm">Update</a></td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                            <a href="register/admin" class="btn btn-light float-right">Add Admin</a>
                        </div>
                    </div>
                </div>

                <div class="card">
                    <div class="card-header bg-primary text-white">User List</div>
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table table-bordered">
                                <thead>
                                    <tr>
                                        <th>ID</th>
                                        <th>Username</th>
                                        <th>Email</th>
                                        <th>Operation</th>
                                        <th>Operation</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($user->id); ?></td>
                                            <td><?php echo e($user->username); ?></td>
                                            <td><?php echo e($user->email); ?></td>
                                            <td><a href=<?php echo e('/deleteUser/' . $user['id']); ?>

                                                    class="btn btn-danger btn-sm">Delete</a></td>
                                            <td><a href=<?php echo e('/edit-user/' . $user['id']); ?>

                                                    class="btn btn-danger btn-sm">Update</a></td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                            <a href="register/addUser" class="btn btn-light float-right">Add User</a>
                        </div>
                    </div>
                </div>

                <div class="card">
                    <div class="card-header bg-primary text-white">Secondary Admin List</div>
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table table-bordered">
                                <thead>
                                    <tr>
                                        <th>ID</th>
                                        <th>Name</th>
                                        <th>Email</th>
                                        <th>Operation</th>
                                        <th>Operation</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $authors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $author): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($author->id); ?></td>
                                            <td><?php echo e($author->name); ?></td>
                                            <td><?php echo e($author->email); ?></td>
                                            <td><a href=<?php echo e('deleteAuthor/' . $author['id']); ?>

                                                    class="btn btn-danger btn-sm">Delete</a></td>
                                            <td><a href=<?php echo e('/edit-author/' . $author['id']); ?>

                                                    class="btn btn-danger btn-sm">Update</a></td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                            <a href="register/author" class="btn btn-light float-right">Add Secondary Admin</a>
                        </div>
                    </div>
                </div>

                <div class="mt-3 d-flex justify-content-end">
                    <a href="logout" class="btn btn-light">LOGOUT</a>
                </div>
            </div>
        </div>
    </div>
</body>
<?php /**PATH C:\Users\PC\Desktop\ADVANCED WEB APPLICATION DEVELOPMENT\AWAD-Assignment-main\Assignment\resources\views/admin.blade.php ENDPATH**/ ?>