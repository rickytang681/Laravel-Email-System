<html>

<head>
    <link rel="stylesheet" href="<?php echo e(asset('css/style.css')); ?>">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css"
        integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
</head>

<body>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card">
                    <div class="card-header">Dashboard</div>
                    <div class="card-body">
                        <?php if(session()->has('email')): ?>
                            <p>User Email: <?php echo e(session('email')); ?></p>
                        <?php endif; ?>
                        Hi, <?php echo e(session('email')); ?>! You are seccess log in to this site!!
                    </div>
                </div><br>
                <div class="d-flex justify-content-end">
                    <a href="logout" class="btn btn-light">LOGOUT</a>
                </div>
            </div>
        </div>
    </div>
</body>

</html>
<?php /**PATH C:\Users\PC\AWAD-Assignment-main\resources\views/user.blade.php ENDPATH**/ ?>