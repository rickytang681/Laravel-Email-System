

<html>
    <head>
        <link rel="stylesheet" href="css/inbox.css">
        <script src="<?php echo e(asset('js/showEmailDetails.js')); ?>"></script>
    </head>
    <body>
        <?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>    

        
        <div class="tab">
            <?php $__currentLoopData = $emails; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $email): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <button class="tablinks" onclick="openCity(event, '<?php echo e($email['header']); ?>')"><?php echo e($email['header']); ?></button>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        
        <?php $__currentLoopData = $emails; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $email): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div id="<?php echo e($email['header']); ?>" class="tabcontent">
                <h1><?php echo e($email['header']); ?></h1>
                <h4><?php echo e($email['created_at']); ?></h4>
                <p><b><?php echo e($email['sender_email']); ?></b></p>
                <hr>
                <p><?php echo e($email['content']); ?></p>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        
    </body>
</html><?php /**PATH C:\Users\PC\AWAD-Assignment-main\resources\views/inbox.blade.php ENDPATH**/ ?>