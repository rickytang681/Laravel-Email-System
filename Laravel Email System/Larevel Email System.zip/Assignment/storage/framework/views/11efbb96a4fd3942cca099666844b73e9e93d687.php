
<head>
    <link rel="stylesheet" href="css/navbar.css  ">
</head>
<header>
    <h1 class="logo">CODEBLOGGER</h1>
    <input type="checkbox" id="nav-toggle" class="nav-toggle" />
    <nav>
      <ul>
        <li><a href="<?php echo e(route('newMessages')); ?>">New Message</a></li>
        <li><a href="<?php echo e(route('inbox')); ?>">Inbox</a></li>
        <li><a href="<?php echo e(route('welcome')); ?>">Quit</a></li>
      </ul>
    </nav>
    <label for="nav-toggle" class="nav-toggle-label">
      <span></span>
    </label>
</header><?php /**PATH C:\Users\PC\AWAD-Assignment-main\resources\views/layouts/app.blade.php ENDPATH**/ ?>